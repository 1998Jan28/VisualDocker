/* eslint-disable */
import { login, logout, getInfo } from '@/api/user'
import { getToken, setToken, removeToken } from '@/utils/auth'
import { resetRouter } from '@/router'

const state = {
    token: getToken(),
    name: '',
    avatar: 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif',
    ip: '',
    port: '',
}

const mutations = {
    SET_TOKEN: (state, token) => {
        state.token = token
    },
    SET_NAME: (state, name) => {
        state.name = name
    },
    SET_AVATAR: (state, avatar) => {
        state.avatar = avatar
    },
    SET_IP: (state, ip) => {
        state.ip = ip
    },
    SET_PORT: (state, port) => {
        state.port = port
    }
}

const actions = {
    // user login
    login({ commit }, userInfo) {
        const { ip, port } = userInfo
        return new Promise((resolve, reject) => {
            login({ ip: ip, port: port }).then(response => {
                const { msg } = response
                console.log(msg == 'success')
                if (msg == 'success') {
                    commit('SET_TOKEN', ip + ":" + port)
                    setToken(ip + ":" + port)

                    commit('SET_NAME', ip + ":" + port)
                    commit('SET_IP', ip)
                    commit('SET_PORT', port)
                    commit('SET_AVATAR', 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif')
                } else {
                    commit('SET_TOKEN', '')
                    commit('SET_NAME', '')
                    commit('SET_IP', '')
                    commit('SET_PORT', '')
                    commit('SET_AVATAR', 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif')
                    setToken('')
                    throw new Error("error")
                }
                console.log(state)
                resolve()
            }).catch(error => {
                console.log(error)
                reject(error)
            })
        })
    },

    // get user info
    getInfo({ commit }, data) {
        console.log(data.ip)
        console.log("getINFO")
        return new Promise((resolve, reject) => {
            getInfo({ ip: data.ip, port: data.port }).then(response => {
                const { dockerInfo } = response
                console.log("userInfo")
                if (!dockerInfo) {
                    reject('Verification failed, please Login again.')
                }
                // console.log(response)
                // commit('SET_NAME', response.dockerInfo.ID)
                commit('SET_AVATAR', 'https://wpimg.wallstcn.com/f778738c-e4f8-4870-b634-56703b4acafe.gif')
                commit('SET_NAME', getToken())
                commit('SET_IP', getToken().split(":")[0])
                commit('SET_PORT', getToken().split(":")[1])
                resolve(response)
            }).catch(error => {
                reject(error)
            })
        })
    },

    // user logout
    logout({ commit, state }) {
        return new Promise((resolve, reject) => {
            commit('SET_TOKEN', '')
            commit('SET_NAME', '')
            commit('SET_IP', '')
            commit('SET_PORT', '')
            removeToken()
            resetRouter()
            resolve()
        })
    },

    // remove token
    resetToken({ commit }) {
        return new Promise(resolve => {
            commit('SET_TOKEN', '')
            removeToken()
            resolve()
        })
    }
}

export default {
    namespaced: true,
    state,
    mutations,
    actions
}