import request from '@/utils/request'

export function getImageList(data) {
    return request({
        url: '/image/list',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port
        }
    })
}

export function getContainerList(data) {
    return request({
        url: '/container/list',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port
        }
    })
}

export function getContainer(data, shortId) {
    return request({
        url: '/container/info',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port,
            containerID: shortId
        }
    })
}

export function getNetworkList(data) {
    return request({
        url: '/network/list',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port
        }
    })
}

export function getVolumeList(data) {
    return request({
        url: '/volume/list',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port
        }
    })
}

export function addContainer(data, ip, port) {
    return request({
        url: '/container/run',
        method: 'get',
        params: {
            type: 'remote',
            ip: ip,
            port: port,
            image: data.image,
            command: data.command,
            insidePort: data.insidePort,
            protocol: data.protocol,
            outsidePort: data.outsidePort
        }
    })
}

export function startContainer(data) {
    return request({
        url: '/container/start',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port,
            containerID: data.shortId
        }
    })
}

export function stopContainer(data) {
    return request({
        url: '/container/stop',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port,
            containerID: data.shortId
        }
    })
}

export function reloadContainer(data) {
    return request({
        url: '/container/reload',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port,
            containerID: data.shortId
        }
    })
}