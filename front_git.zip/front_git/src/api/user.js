import request from '@/utils/request'

export function login(data) {
    return request({
        url: '/login',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port
        }
    })
}

export function getInfo(data) {
    return request({
        url: '/clientInfo',
        method: 'get',
        params: {
            type: 'remote',
            ip: data.ip,
            port: data.port
        }
    })
}