<template>
  <div class="dashboard-editor-container">
    <panel-group @handleSetLineChartData="handleSetLineChartData" :panel-data="panelData" />

    <el-row style="background:#fff;padding:16px 16px 0;margin-bottom:32px;">
      <line-chart :chart-data="lineChartData" />
    </el-row>
  
    <el-row :gutter="32">
      <!-- <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <raddar-chart />
        </div>
      </el-col> -->
      <el-col :xs="24" :sm="24" :lg="8" style="margin-left:200px;">
        <div class="chart-wrapper">
          <pie-chart :pie-data="pieData" />
        </div>
      </el-col>
      <el-col :xs="24" :sm="24" :lg="8">
        <div class="chart-wrapper">
          <bar-chart  :bar-data="barData"/>
        </div>
      </el-col>
    </el-row>

    <!-- <el-row :gutter="8">
      <el-col :xs="{span: 24}" :sm="{span: 24}" :md="{span: 24}" :lg="{span: 12}" :xl="{span: 12}" style="padding-right:8px;margin-bottom:30px;">
        <transaction-table />
      </el-col>
      <el-col :xs="{span: 24}" :sm="{span: 12}" :md="{span: 12}" :lg="{span: 6}" :xl="{span: 6}" style="margin-bottom:30px;">
        <todo-list />
      </el-col>
      <el-col :xs="{span: 24}" :sm="{span: 12}" :md="{span: 12}" :lg="{span: 6}" :xl="{span: 6}" style="margin-bottom:30px;">
        <box-card />
      </el-col>
    </el-row> -->
  </div>
</template>

<script>
import PanelGroup from './components/PanelGroup'
import LineChart from './components/LineChart'
import PieChart from './components/PieChart'
import BarChart from './components/BarChart'
import {getImageList,getContainerList,getNetworkList,getVolumeList} from '@/api/docker'

const lineChartData = {
  newVisitis: {
    count: [0, 0, 0, 0, 0, 0, 0]
  },
  messages: {
    count: [0, 0, 0, 0, 0, 0, 0]
  },
  purchases:{
    count: [0, 0, 0, 0, 0, 0, 0]
  },
  shoppings:{
    count: [0, 0, 0, 0, 0, 0, 0]
  }
};
const panelData = {
  Image:0,
  Container:0,
  Network:0,
  Volume:0
}

export default {
  name: 'DashboardAdmin',
  components: {
    PanelGroup,
    LineChart,
    PieChart,
    BarChart
  },
  methods: {
    handleSetLineChartData(type) {
      this.lineChartData = lineChartData[type]
    },
    fun_data(aa){
        var date1 = new Date(),
        time1=date1.getFullYear()+"-"+(date1.getMonth()+1)+"-"+date1.getDate();//time1表示当前时间
        var date2 = new Date(date1);
        date2.setDate(date1.getDate()+aa);
        var time2 = date2.getFullYear()+"-"+(date2.getMonth()+1)+"-"+date2.getDate();
        return new Date(time2);
    }
  },
  mounted:async function(){
    // console.log(this.$store.state.user);
    // user = this.$store.state.user.ip
    console.log("begin")
    const pieData = {
      name:['running','exited','created'],
      part:[]
    }
    const barData = {
      name:[],
      data:[]
    };
    // console.log(user)
    await getImageList({ip:this.$store.state.user.ip,port:this.$store.state.user.port}).then( res => {
      console.log(res)
      for (var i=-6;i<=0;i++){
        var count = 0;
        var time = this.fun_data(i)
        for(var j = 0; j < res.images.length; j++){
          if(new Date(res.images[j].createTime).getTime() <= new Date(time).getTime()){
            count++;
          }
        }
        lineChartData.newVisitis.count[i+6]=count
      }
      for(var i = 0; i < 5; i++){
        barData.name[i] = res.images[i].repoTag
        barData.data[i] = parseInt(res.images[i].attrs.Size/(1024*1024))
      }
      console.log(lineChartData.newVisitis.count)
      panelData.Image = res.images.length
    });
    await getContainerList({ip:this.$store.state.user.ip,port:this.$store.state.user.port}).then(res=>{
      console.log(res)
      for (var i=-6;i<=0;i++){
        var count = 0;
        var time = this.fun_data(i)
        for(var j = 0; j < res.containers.length; j++){
          if(new Date(res.containers[j].createTime).getTime() <= new Date(time).getTime()){
            count++;
          }
        }
        lineChartData.messages.count[i+6]=count
      }
      var runningCount = 0;
      var exitedCount = 0;
      var createdCount = 0;
      for(var i = 0; i < res.containers.length;i++){
        if(res.containers[i].status=='running'){
          runningCount++;
        }
        else if(res.containers[i].status=='exited'){
          exitedCount++;
        }
        else if(res.containers[i].status=='created'){
          createdCount++;
        }
      }
      pieData.part[0] = runningCount;
      pieData.part[1] = exitedCount;
      pieData.part[2] = createdCount;
      console.log(lineChartData.messages.count)
      panelData.Container = res.containers.length
    });
    await getNetworkList({ip:this.$store.state.user.ip,port:this.$store.state.user.port}).then(res=>{
      console.log(res)
      for (var i=-6;i<=0;i++){
        var count = 0;
        var time = this.fun_data(i)
        for(var j = 0; j < res.networks.length; j++){
          if(new Date(res.networks[j].attrs.Created).getTime() <= new Date(time).getTime()){
            count++;
          }
        }
        lineChartData.purchases.count[i+6]=count
      }
      console.log(lineChartData.purchases.count)
      panelData.Network = res.networks.length
    });
    await getVolumeList({ip:this.$store.state.user.ip,port:this.$store.state.user.port}).then(res=>{
      console.log(res)
      for (var i=-6;i<=0;i++){
        var count = 0;
        var time = this.fun_data(i)
        for(var j = 0; j < res.volumes.length; j++){
          if(new Date(res.volumes[j].attrs.CreatedAt).getTime() <= new Date(time).getTime()){
            count++;
          }
        }
        lineChartData.shoppings.count[i+6]=count
      }
      console.log(lineChartData.shoppings.count)
      panelData.Volume = res.volumes.length
    });
    this.lineChartData = lineChartData.newVisitis
    this.panelData = panelData
    this.pieData = pieData
    this.barData = barData
    console.log("before")
  },
  data() {
    console.log("line",panelData)
    return {
      lineChartData: "",
      panelData: "",
      pieData:"",
      barData:""
    }
  }
}
</script>

<style lang="scss" scoped>
.dashboard-editor-container {
  padding: 32px;
  background-color: rgb(240, 242, 245);
  position: relative;

  .github-corner {
    position: absolute;
    top: 0px;
    border: 0;
    right: 0;
  }

  .chart-wrapper {
    background: #fff;
    padding: 16px 16px 0;
    margin-bottom: 32px;

  }
}
</style>
