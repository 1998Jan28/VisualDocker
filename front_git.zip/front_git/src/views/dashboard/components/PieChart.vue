<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import { debounce } from '@/utils'

const pieData = {
  name:[],
  part:[]
};


export default {
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '300px'
    },
    pieData:{
      type:Object,
      required:true
    }
  },
  data() {
    return {
      chart: null,
      pieData:this.pieData
    }
  },
  watch:{
      pieData:{
        deep:true,
        handler(val){
          const chartData = [];
          this.pieData=val;
          
          console.log("bbb",val);
          for(var i = 0;i<val.name.length;i++){
            var temp={};
            this.$set(temp,"value",this.pieData.part[i]);
            this.$set(temp,"name",this.pieData.name[i]);
            console.log(temp);
            chartData.push(temp);
          }
          console.log(chartData);
          this.chart.setOption({
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
          },
          legend: {
            left: 'center',
            bottom: '10',
            data: this.pieData.name
          },
          calculable: true,
          series: [
            {
              name: '容器状态',
              type: 'pie',
              roseType: 'radius',
              radius: [15, 95],
              center: ['50%', '38%'],
              data: chartData,
              animationEasing: 'cubicInOut',
              animationDuration: 2600
            }
          ]
        })
        }
      }
  },
  mounted() {
    this.initChart()
    this.__resizeHandler = debounce(() => {
      if (this.chart) {
        this.chart.resize()
      }
    }, 100)
    window.addEventListener('resize', this.__resizeHandler);
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    window.removeEventListener('resize', this.__resizeHandler)
    this.chart.dispose()
    this.chart = null
  },
  methods: {
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      // this.chart.setOption({
      //   tooltip: {
      //     trigger: 'item',
      //     formatter: '{a} <br/>{b} : {c} ({d}%)'
      //   },
      //   legend: {
      //     left: 'center',
      //     bottom: '10',
      //     data: pieData.name
      //   },
      //   calculable: true,
      //   series: [
      //     {
      //       name: '授课班级听课占比',
      //       type: 'pie',
      //       roseType: 'radius',
      //       radius: [15, 95],
      //       center: ['50%', '38%'],
      //       data: chartData,
      //       animationEasing: 'cubicInOut',
      //       animationDuration: 2600
      //     }
      //   ]
      // })
    }
  }
}
</script>
