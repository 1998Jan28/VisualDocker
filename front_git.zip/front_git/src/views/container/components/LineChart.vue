<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>

<script>
import echarts from 'echarts'
require('echarts/theme/macarons') // echarts theme
import { debounce } from '@/utils'
import moment from 'moment'
import { addContainer,getContainerList,startContainer,stopContainer,reloadContainer,getContainer } from '@/api/docker'

// var date = new Array()

// var week = new Array('Sun','Mon', 'Tue', 'Wed', 'Thu', 'Fri','Sat')

export default {
  props: {
    className: {
      type: String,
      default: 'chart'
    },
    width: {
      type: String,
      default: '100%'
    },
    height: {
      type: String,
      default: '350px'
    },
    autoResize: {
      type: Boolean,
      default: true
    },
    chartData: {
      type: Object,
      required: true
    }
  },
  data() {
    return {
      chart: null,
      sidebarElm: null,
      timer:"",
      detailsFormVisible:false
    }
  },
  watch: {
    chartData: {
      deep: true,
      handler(val) {
        console.log("isShow",val)
        this.chartData = val
        // this.initChart()
        this.setOptions(val)
      }
    }
  },
  mounted() {
    
    // console.log(date)
    this.initChart()
    if (this.autoResize) {
      this.__resizeHandler = debounce(() => {
        if (this.chart) {
          this.chart.resize()
        }
      }, 100)
      window.addEventListener('resize', this.__resizeHandler)
    }
    
    // 监听侧边栏的变化
    this.sidebarElm = document.getElementsByClassName('sidebar-container')[0]
    this.sidebarElm && this.sidebarElm.addEventListener('transitionend', this.sidebarResizeHandler)
    // console.log("Line",this.chartData)
    // this.setOptions(this.chartData.newVisitis)
  },
  beforeDestroy() {
    if (!this.chart) {
      return
    }
    if (this.autoResize) {
      window.removeEventListener('resize', this.__resizeHandler)
    }

    this.sidebarElm && this.sidebarElm.removeEventListener('transitionend', this.sidebarResizeHandler)
    clearInterval(this.timer)
    this.chart.dispose()
    this.chart = null
  },
  methods: {
      handleClose(done){
      console.log("close");
      this.detailsFormVisible=false
    //   clearInterval(this.timer);
      done();
    },
    sidebarResizeHandler(e) {
      if (e.propertyName === 'width') {
        this.__resizeHandler()
      }
    },
    setOptions({time,data1,data2}) {
      console.log(time)
      this.chart.setOption({
        xAxis: {
          data: time,
          boundaryGap: false,
          axisTick: {
            show: false
          }
        },
        grid: {
          left: 10,
          right: 10,
          bottom: 20,
          top: 30,
          containLabel: true
        },
        tooltip: {
          trigger: 'axis',
          axisPointer: {
            type: 'cross'
          },
          padding: [5, 10]
        },
        yAxis: {
          axisTick: {
            show: false
          }
        },
        legend: {
          data: ['cpu','memory']
        },
        series: [{
          name: 'cpu', itemStyle: {
            normal: {
              color: '#FF005A',
              lineStyle: {
                color: '#FF005A',
                width: 2
              }
            }
          },
          smooth: true,
          type: 'line',
          data: data1,
          animationDuration: 2800,
          animationEasing: 'cubicInOut'
        },{
          name: 'memory',
          smooth: true,
          type: 'line',
          itemStyle: {
            normal: {
              color: '#3888fa',
              lineStyle: {
                color: '#3888fa',
                width: 2
              },
              areaStyle: {
                color: '#f3f8ff'
              }
            }
          },
          data: data2,
          animationDuration: 2800,
          animationEasing: 'quadraticOut'
        }]
      })
    },
    initChart() {
      this.chart = echarts.init(this.$el, 'macarons')
      console.log("line123",this.chartData)
      this.setOptions(this.chartData)
    }
  }
}
</script>
