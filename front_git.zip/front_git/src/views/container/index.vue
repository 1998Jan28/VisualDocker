<template>
  <div class="app-container">
    <!-- table -->
    <el-button @click="dialogFormVisible = true" style="margin-bottom:20px">New</el-button>
    <el-dialog title="New Container" :visible.sync="dialogFormVisible" :before-close="handleClose" >
      <el-form :model="form" v-loading="tablelistLoading">
        <el-form-item label="image" >
          <el-input v-model="form.image" autocomplete="off" placeholder="ubuntu,nginx"></el-input>
        </el-form-item>
        <el-form-item label="command" >
          <el-input v-model="form.command" autocomplete="off" placeholder="/bin/bash"></el-input>
        </el-form-item>
        <el-form-item label="insidePort(可选)" >
          <el-input v-model="form.insidePort" autocomplete="off" placeholder="0-65535"></el-input>
        </el-form-item>
        <el-form-item label="protocol(可选)" >
          <el-input v-model="form.protocol" autocomplete="off" placeholder="tcp,udp,sctp"></el-input>
        </el-form-item>
        <el-form-item label="outsidePort(可选)">
          <el-input v-model="form.parentTel" autocomplete="off" placeholder="0-65535"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false;tablelistLoading=false;">取 消</el-button>
        <el-button type="primary" @click="addContainer">确 定</el-button>
      </div>
    </el-dialog>
    <!-- end table -->
    
    <el-table
      v-loading="listLoading"
      :data="list"
      element-loading-text="Loading"
      border
      fit
      highlight-current-row
    >
    <el-table-column align="center" label="ContainerId" >
        <template slot-scope="scope">
          {{ scope.row.shortId }}
        </template>
      </el-table-column>
      <el-table-column align="center" label="Name">
        <template slot-scope="scope">
          {{ scope.row.name }}
        </template>
      </el-table-column>
      <el-table-column label="status" align="center">
        <template slot-scope="scope">
          {{ scope.row.status }}
        </template>
      </el-table-column>
      <el-table-column label="Image" align="center">
        <template slot-scope="scope">
          {{ scope.row.image }}
        </template>
      </el-table-column>
      <el-table-column label="Created" align="center">
        <template slot-scope="scope">
          {{ scope.row.createTime }}
        </template>
      </el-table-column>
      <el-table-column label="IP Address" align="center">
        <template slot-scope="scope">
          {{ scope.row.attrs.NetworkSettings.IPAddress }}
        </template>
      </el-table-column>
      <el-table-column align="center" prop="created_at" label="操作" width="300">
        <template slot-scope="scope">
          <el-button @click="handleContainer(scope.row.shortId,scope.row.status)" round :type="scope.row.status == 'running' ? 'danger':'success'" size="small">{{scope.row.status == "running" ? "Stop":"Start"}}</el-button>
          <el-button @click="restartContainer(scope.row.shortId)" round type="warning" size="small">Restart</el-button>
          <el-button @click="detailsFormVisible=true;shortId=scope.row.shortId;" round type="primary" size="small">Inspect</el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog title="New Container" :visible.sync="detailsFormVisible" :before-close="handleClose" @open="inspect()">
      <line-chart :chart-data="cpulinechart" style="width:100%;height:400px"/>
    </el-dialog>
        <!-- Memory: -->
        <!-- <line-chart :chart-data="memorylinechart" style="width:100%;height:100px"/> -->
    
  </div>
</template>

<script>
import { addContainer,getContainerList,startContainer,stopContainer,reloadContainer,getContainer } from '@/api/docker'
import LineChart from './components/LineChart'
import { setInterval, clearInterval } from 'timers'
export default {
  filters: {
  },
  components: {
    LineChart,
  },
  data() {
    return {
    cpulinechart:{
      time:[new Date().getMinutes()],
      data1:[0],
      data2:[0]
    },
      list: null,
      listLoading: true,
      dialogFormVisible:false,
      detailsFormVisible:false,
      tablelistLoading:false,
      shortId:'',
      timer:"",
      form:{
        image:'',
        command:'',
        insidePort:'',
        protocol:'',
        outsidePort:'',
      }
    }
  },
  created() {
    this.fetchData()
  },
  methods: {
    handleClose(done){
      console.log("close");
      this.detailsFormVisible=false
      this.dialogFormVisible=false
      clearInterval(this.timer);
      done();
    },
    addContainer(){
      console.log(this.form);
      this.tablelistLoading = true

      addContainer(this.form,this.$store.state.user.ip,this.$store.state.user.port).then(response=>{
        this.fetchData()
        this.tablelistLoading = false
        this.dialogFormVisible = false
      })
    },
    async fetchData() {
      this.listLoading = true
      await getContainerList({ip:this.$store.state.user.ip,port:this.$store.state.user.port}).then(response => {
        this.list = response.containers;
        console.log(response);
        this.listLoading = false
      })
    },
    async handleContainer(shortId,status){
        if(status == 'running'){
           await stopContainer({ip:this.$store.state.user.ip,port:this.$store.state.user.port,shortId:shortId})
        }
        else
            await startContainer({ip:this.$store.state.user.ip,port:this.$store.state.user.port,shortId:shortId})
        this.fetchData()
    },
    async restartContainer(shortId){
        await reloadContainer({ip:this.$store.state.user.ip,port:this.$store.state.user.port,shortId:shortId})
        this.fetchData()
    },
    inspect(){
        console.log("open")
        // this.cpulinechart=this.shortId
      var tmp = 0;
      var shortId = this.shortId
      var cpulinechart = {
            time:[new Date().getMinutes()],
            data1:[0],
            data2:[0]
        }
      console.log("inspect")
      this.cpulinechart = cpulinechart
      this.timer = setInterval(() =>{
        console.log(112233)
        
         getContainer({ip:this.$store.state.user.ip,port:this.$store.state.user.port},shortId).then(response => {
            // console.log("循环",response.info.attrs.HostConfig.NanoCpus)
            cpulinechart.time.push(new Date().getMinutes())
            cpulinechart.data1.push(response.info.attrs.HostConfig.NanoCpus/(1024*1024))
            cpulinechart.data2.push(response.info.attrs.HostConfig.Memory/(1024*1024))
            console.log(cpulinechart)
        })
        this.cpulinechart = cpulinechart
      },30000);
        
    }
  }
}
</script>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
</style>